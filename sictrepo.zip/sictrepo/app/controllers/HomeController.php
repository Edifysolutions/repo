<?php

class HomeController extends BaseController {

	public function home() { return View::make('index.home'); }

	public function terms() { return View::make('index.terms'); }

	public function contact() { return View::make('index.contact'); }

	public function getLogin() { return View::make('users.login'); }

	public function postLogin() {
		$validator = Validator::make(Input::all(), ['username' => 'required|min:3', 'password' => 'required|min:5']);

        if($validator->fails()) { return Redirect::route('getLogin')->withErrors($validator)->withInput(); }

        $auth = Auth::attempt(['username' => Input::get('username'), 'password' => Input::get('password')]);
            // Redirect user back to the intended page  
            return ($auth)
                ? Redirect::route('getDashboard')
                : Redirect::route('getLogin')->withInput()->with('m', 'Wrong username, password combination.');
	}

	public function getDashboard() { return View::make('index.dashboard'); }

    public function getLogout() {
        Auth::logout();
        return Redirect::route('getLogin')->with('m', 'You\'re logged out!');
    }

}
