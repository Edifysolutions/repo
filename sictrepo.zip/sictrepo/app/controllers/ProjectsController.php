<?php

class ProjectsController extends \BaseController {

	public function index() {
		$projects = Project::OrderBy('id', 'desc')->with('department')->paginate(20);
		return View::make('admin.getProjectsAdmin', compact('projects'));
	}

	public function create() {
		$departments = Department::whereVisible(1)->get();
		return View::make('projects.create', compact('departments'));
	}

	// get course listing for a prticular department
	public function getProjectsForDept($slug) {

		$department = Department::whereSlug($slug)->whereVisible(1)->first();

		$projects = Project::OrderBy('id', 'desc')->whereDepartmentId($department->id)->whereVisible(1)->paginate(20);

		return View::make('projects.getProjectsForDept', compact('department', 'projects'))
			->with('title', ucwords($department->name));
	}

	public function store() {
		try{
			$validator = Validator::make(Input::all(),
	            array(
	            	'department' => 'required|Numeric',
	                'year_of_submission' => 'required|DateFormat:Y|Before:2016',
	                'student_name' => 'required|min:5',
	                'surpervisor_name' => 'required|min:5|max:100',
	                'topic' => 'required|min:5|max:250|unique:projects',
	                'body' => 'required|min:20',//|max:66000
	                'methodology' => 'min:5|max:250',
	                'references' => 'min:5|max:250'
	                )
	            );
	        if($validator->fails()) {
	            return Redirect::route('project.create')->withErrors($validator)->withInput()->withM('We encountered some error(s) in the form');
	        }
				// create project number
				$project_number = 'pr'.str_random(12);
				$slug = Str::slug(Input::get('topic'));

				$p = Project::create(array(
				'department_id' => Input::get('department'),
				'project_number' => $project_number,
				'slug' 	=> $slug,
				'year_of_submission' => Input::get('year_of_submission'),
				'student_name' => Input::get('student_name'),
				'surpervisor_name' => Input::get('surpervisor_name'),
				'topic' => Input::get('topic'),
				'body' => Input::get('body'),
				'methodology' => Input::get('methodology'),
				'references' => Input::get('references'),
				'visible' => Input::get('visible'),
				
				));
	               
	            if($p) {
	                return Redirect::route('project.create')
	                	->withM('Project Created. We seem to be doing good today!')->withMType('success');

	            } else {
			        return Redirect::back()->withInput()->withM('Could not create project');
	            }
	    } catch(Exception $e) {
	    	return Redirect::back()->withInput()->withM('Exception: '.$e->getMessage());	
	    } 
	}

	public function show($id) {
		$project = Project::with('department')->findOrFail($id);
		if(empty($project)) { return Redirect::back()->withM('Invalid Project Identity'); }

		$rProjects = Project::OrderBy('id', 'desc')->whereDepartmentId($project->department->id)->whereVisible(1)->take(4)->get();
		
		return View::make('projects.getProjectItem', compact('project', 'rProjects'))
			->with('title', $project->title);
	}

	public function getSearchBlank() {
		$departments = Department::whereVisible(1)->get();
		return View::make('projects.searchBlank', compact('departments'));
	}

	public function getSearch() {
		$v = Validator::make(Input::all(), [
			'department' => 'required|max:1',
			'topic' => 'min:3|max:100',
			'student_name' => 'min:3|max:80',
			'surpervisor_name' => 'min:3|max:80',
			'year_of_submission' => 'DateFormat:Y|Before:2016|min:4|max:4'
			]);
		if($v->fails()) { return Redirect::route('getSearchBlank')->withInput()->withErrors($v); }
		else {
			$department = Request::get('department');
			$topic = Request::get('topic');
			$year_of_submission = Request::get('year_of_submission');
			$student_name = Request::get('student_name');
			$surpervisor_name = Request::get('surpervisor_name');

			if(empty($topic) && empty($year_of_submission) && empty($student_name) && empty($surpervisor_name)) {
				return Redirect::route('getSearchBlank')->withM('Please provide a search query.')->withMType('danger');
			}

			$sql = new Project();
			$sql = $sql->OrderBy('topic','asc')->with('department');
			if(is_numeric($department) && $department > 0) { $sql->whereDepartmentId($department); }
			
			if(strlen($topic) > 1) { $sql->where('topic','LIKE',"%".$topic."%"); } 
			if(strlen($year_of_submission) > 1) { $sql->where('year_of_submission','LIKE',"%$year_of_submission%"); }
			if(strlen($student_name) > 1) { $sql->where('student_name','LIKE',"%$student_name%"); }
			if(strlen($surpervisor_name) > 1) { $sql->where('surpervisor_name','LIKE',"%$surpervisor_name%"); }
			//return $sql->get(['topic']);
			return View::make('projects.searchDefault', compact('topic','year_of_submission','student_name','surpervisor_name'))->with('searchResults', $sql->paginate(20));

		}
		
	}

	public function edit($id) {
		//
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /projects/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /projects/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}

}