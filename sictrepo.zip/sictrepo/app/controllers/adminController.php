<?php

class AdminController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 * GET /admin
	 *
	 * @return Response
	 */
	public function index()
	{
		 $staffs=DB::table('users')->where('user_level', '<>', '10')->get();

		return View::make('users.index', compact('staffs'));
	}

	/**
	 * Show the form for creating a new resource.
	 * GET /admin/create
	 *
	 * @return Response
	 */
	public function create()
	{
		$dept=Department::all();
		return View::make('users.create', compact('dept'));
	}

	/**
	 * Store a newly created resource in storage.
	 * POST /admin
	 *
	 * @return Response
	 */
	public function store()
	{
		$user=User::create(Input::all());
		if ($user) {
			return Redirect::back()->with('m', 'User Has been Added Successfully')->withMType('success');
		}
		  return Redirect::back()->with('m', 'Opps Sorry there was an error')->withMType('danger');;
	}

	/**
	 * Display the specified resource.
	 * GET /admin/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 * GET /admin/{id}/edit
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /admin/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /admin/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		$user=User::findOrFail($id)->delete();
		if ($user) {
		  return Redirect::back()->with('m', 'Deleted Successfully')->withMType('success');
		}
		else{
		  return Redirect::back()->with('m', 'Opps Sorry there was an error')->withMType('danger');
		}

	}

}