<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateProjectsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('projects', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('department_id');
			$table->string('project_number');
			$table->string('slug');
			$table->decimal('price', 15,2);
			$table->integer('pages');
			$table->string('chapters');
			$table->string('title');
			$table->text('body');
			$table->string('methodology');
			$table->string('references');
			$table->integer('visible');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('projects');
	}

}
