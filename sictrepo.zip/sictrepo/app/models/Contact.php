<?php

class Contact extends \Eloquent {
	protected $guarded = ['id'];

	protected $fillable = ['ticket_no','fullname','email','phone_number','reason_for_contact','comment','visible'];
}