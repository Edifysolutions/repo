<?php

class Department extends \Eloquent {
	protected $fillable = [];

	public function projects() {
		return $this->hasMany('Project');
	}
}