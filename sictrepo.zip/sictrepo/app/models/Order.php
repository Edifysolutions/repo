<?php

class Order extends \Eloquent {
	protected $guarded = ['id'];
	protected $fillable = ['project_id', 'fullname', 'email', 'phone_number', 'newOrder'];
}