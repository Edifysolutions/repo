<?php

class Project extends \Eloquent {
	protected $guarded = ['id'];
	protected $fillable = ['department_id', 'project_number', 'slug', 'year_of_submission', 'student_name', 'surpervisor_name', 'topic', 'body', 'methodology', 'references','visible'];

	public function department() {
		return $this->belongsTo('Department');
	}
}