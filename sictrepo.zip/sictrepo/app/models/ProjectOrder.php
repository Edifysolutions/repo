<?php

class ProjectOrder extends \Eloquent {
	protected $guarded = ['id'];
	protected $fillable = ['fullname', 'email', 'title', 'description'];
}