<?php
# CSRF Protection
Route::when('*', 'csrf', ['POST', 'PUT', 'PATCH', 'DELETE']);

Route::get('/sictrepository', 'HomeController@home');

// search projects on sictrepo route
Route::get('/search-results', array('uses' => 'ProjectsController@getSearch', 'as' => 'getSearch'));
Route::get('/search-page', array('uses' => 'ProjectsController@getSearchBlank', 'as' => 'getSearchBlank'));

Route::group(array('before' => 'guest'), function() {

	Route::post('/staff-login', array('uses' => 'HomeController@postLogin', 'as' => 'postLogin'));
	// admin login
	Route::get('/staff-login', array('uses' => 'HomeController@getLogin', 'as' => 'getLogin'));

}); //end protected routes for unauthenticated routes


Route::get('/logoutAdmin', array('uses' => 'HomeController@getLogout', 'as' => 'getLogout'));

Route::get('/', array('uses' => 'HomeController@home', 'as' => 'home'));

Route::get('/about', array('uses' => 'HomeController@about', 'as' => 'getAbout'));

Route::get('/contact-us', array('uses' => 'HomeController@contact', 'as' => 'getContact'));

Route::get('/terms', array('uses' => 'HomeController@terms', 'as' => 'getTerms'));

Route::get('/request-project', array('uses' => 'HomeController@customProject', 'as' => 'getCustomProject'));

Route::get('/browse-all-projects', array('uses' => 'ProjectsController@browseProjects', 'as' => 'getBrowseProjects'));

// start protected routes
Route::group(array('before' => 'auth'), function() {

		Route::resource('/project', 'ProjectsController', ['only' => ['index','store', 'create', 'edit', 'update', 'destroy']]);

		Route::post('/edit-project/{projectNumber}', array('uses' => 'ProjectsController@update', 'as' => 'admin.postEditProject'));

	Route::get('/edit-project/{projectNumber}', array('uses' => 'ProjectsController@getEdit', 'as' => 'getEditProject'));

	Route::get('/dashboardAdmin', array('uses' => 'HomeController@getDashboard', 'as' => 'getDashboard'));

	Route::get('/dashboardAdmin/browse-projects/{projectNumber}', array('uses' => 'ProjectsController@getProjectItemAdmin', 'as' => 'admin.getProjectItemAdmin'));

	Route::get('/addUser', ['as' => 'addUser', 'uses'=> 'adminController@create']);
	Route::post('addAction', ['as' => 'addPost', 'uses' => 'adminController@store']);

	Route::get('allUsers', ['as' => 'allUsers', 'uses' => 'adminController@index']);
	Route::get('DeleteUser/{id}', 'adminController@destroy');
});

Route::get('/{slug}', array('uses' => 'ProjectsController@getProjectsForDept', 'as' => 'getProjectsForDept'));

Route::get('project/{id}', array('uses' => 'ProjectsController@show', 'as' => 'project.show'));