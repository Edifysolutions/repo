@extends('layout.master')
@section('content')

  @include('partials/pgTop')
  @include('admin/partials/topNav')
  @if( $errors->count() )
  <div class="alert alert-danger alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
  <strong>We encountered the following errors:</strong>
  <ul>
    @foreach($errors->all() as $message)
    <li>{{ $message }}</li>
    @endforeach
  </ul>
  </div>
@endif
  <div class="col-md-12 col-sm-12">
    <div class="col-md-3 col-sm-12">@include('admin/partials/sideNav')</div>
    <div class="col-md-9 col-sm-12">
      <form method="post" action="{{ URL::route('admin.postEditProject', $project->project_number) }}" class="sky-form boxed">
          <input type="hidden" name="_token" value="{{ csrf_token() }}">
          <input type="hidden" name="formerTitle" value="{{$project->title}}">
          <header>Update Project Item Form</header>
          <fieldset>
          <div class="row">
            <section class="col col-md-6">
            <label for="department">Department:</label>
            <select name="department" class="form-control">
              @foreach($departments as $department)
                <?php ($project->department_id == $department->id) ? $selected = 'selected="selected"' : $selected =''; ?>
                <option value="{{ $department->id }}" {{$selected}}>{{ $department->name }}</option>
              @endforeach
            </select>
            </section>
             
            <section class="col col-md-6">
              <label for="price">Price:</label>
              <input type="text" name="price" class="form-control" value="{{ (Input::old('price')) ? Input::old('price') : $project->price }}">
            </section>
          </div>

          <div class="row">
            <section class="col col-md-6">
              <label class="label" for="pages">Pages:</label>
              <input type="text" name="pages" class="form-control" value="{{ (Input::old('pages')) ? Input::old('pages') : $project->pages }}">
            </section>

            <section class="col col-md-6">
              <label class="label" for="chapters">Chapters:</label>
              <input type="text" name="chapters" class="form-control" value="{{ (Input::old('chapters')) ? Input::old('chapters') : $project->chapters }}">
            </section>
          </div>

          <div class="row">
            <section class="col col-md-12">
              <label class="label" for="title">Project Title:</label>
              <input type="text" name="title" class="form-control" value="{{ (Input::old('title')) ? Input::old('title') : $project->title }}">
            </section>
          </div>

              <label class="label">Project Body:</label>
              <textarea name="body" id="txtarea" rows="15">{{ (Input::old('body')) ? Input::old('body') : strip_tags($project->body, "<b><p><br><i><u><a><h1><h2><h3><h4<h5><h6><strong><embed><object><param><small><span><em><img>") }}</textarea>
              <br>

            <section class="col col-md-6">
              <label class="label" for="methodology">Methodology:</label>
              <input type="text" name="methodology" class="form-control" value="{{ (Input::old('methodology')) ? Input::old('methodology') : $project->methodology }}">
            </section>

            <section class="col col-md-6">
              <label class="label" for="references">Reference(s):</label>
              <input type="text" name="references" class="form-control" value="{{ (Input::old('references')) ? Input::old('references') : $project->references }}">
            </section>

              <div class="form-group">
                <div class="col-md-4 col-sm-12 col-xs-12 nopadding">
                  <label class="label" for="visible">Make Project Visible Online? </label>
                </div>
                <div class="col-md-8 nopadding">
                  <div class="row">
                    <div class="col-md-2 col-sm-2 col-xs-4"><!-- selected="selected" radio below uses checked -->
                      <label class="radio"><input type="radio" name="visible" value="1" <?php if($project->visible == 1) { echo 'checked="checked"'; } ?>><i></i>Yes</label>
                    </div>
                    <div class="col-md-10 col-sm-2 col-xs-8">
                      <label class="radio"><input type="radio" name="visible" value="0" <?php if($project->visible == 0) { echo 'checked="checked"'; } ?>><i></i>No</label>
                    </div>
                  </div>
                </div>
              </div>


          </fieldset>

        <footer>
          <a href="{{URL::route('admin.getProjects')}}" class="btn btn-danger"><i class="fa fa-close"></i>Cancel</a>
          <button type="submit" class="button"><i class="fa fa-save"></i> Update Project</button>
        </footer>

     	</form>
    </div><!-- end col-md-9 -->
  </div>
  @include('partials/pgBottom')

{{ HTML::script('assets/tinymce/js/tinymce/tinymce.min.js') }}
<script>
	tinymce.init({
		selector: '#txtarea',
		skin: 'pepper-grinder',
		plugins: 
			'wordcount, insertdatetime,'
		});
</script>
<!--end tinymce -->
@stop