@extends('layout.master')
@section('content')

  @include('partials/pgTop')
  @include('admin/partials/topNav')
  <div class="col-md-12 col-sm-12">
    <div class="col-md-3 col-sm-12">@include('admin/partials/sideNav')</div>
    <div class="col-md-9 col-sm-12">

       <table class="table table-striped" style="width:inherit;overflow:break">
       	<thead>
       		<th width="100px">PROJECT TOPIC</th>
       		<th class="text-center">DEPARTMENT</th>
          <th class="text-center">VISIBLE</th>
       	</thead>
       	<tbody>
       		<?php $sn = 1; ?>
       		@foreach($projects as $project)
       			<tr>
       				<td width="100px">
                <a href="{{ URL::route('project.edit', $project->id) }}" class="btn" title="Click to edit {{ $project->topic }}"> 
                  @if(strlen($project->topic) > 65)  {{ substr($project->topic, 0, 65).'...' }} @else {{ $project->topic }} @endif 
                </a>
              </td>
       				<td class="text-center"> {{ $project->department->name }} </td>
              <td class="text-center"> @if($project->visible == 1) {{ 'Yes' }} @else {{ 'No' }} @endif </td>
       			</tr>
       		@endforeach
       	</tbody>
       </table>
       <br>
       {{ $projects->links() }}

       </div><!-- end col-md-9 -->

     </div>
     @include('partials/pgBottom')
@stop