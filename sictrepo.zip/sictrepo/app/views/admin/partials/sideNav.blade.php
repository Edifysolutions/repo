<!--MENU -->
<ul class="side-nav list-group margin-bottom30">
	<!--  active --><li class="list-group-item"><a href="{{URL::route('getDashboard')}}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
	<li class="list-group-item"><a href="{{URL::route('project.index')}}"><i class="fa fa-edit"></i> All Projects</a></li>
	<li class="list-group-item"><a href="{{URL::route('project.create')}}"><i class="fa fa-plus"></i> Add Project</a></li>
	@if(Auth::user()->user_level == 10)
	<li class="list-group-item"><a href="allUsers"><i class="fa fa-user"></i> View Users</a></li>
	<li class="list-group-item"><a href="{{route('addUser')}}"><i class="fa fa-user"></i> Add User</a></li>
	@endif
	<!-- <li class="list-group-item"><a href="#"><i class="fa fa-envelope"></i> Contact Messages</a></li> -->
</ul>
<!-- /MENU--> 