<p style="border:1px solid #ccc">
	<a class="btn" href="{{URL::route('getLogout')}}" title="Logout">Logout</a> | 
	<a  class="btn" href="javascript:history.go(-1)" title="Go back one step only"><i class="fa fa-arrow-left"></i> Go Back One Step</a>
</p>