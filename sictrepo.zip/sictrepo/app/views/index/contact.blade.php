@extends('layout.master')
@section('content')
<!-- CONTENT -->
<section>
	<div class="container">

		<div class="row">

			<!-- FORM -->
			<div class="col-md-8 boxed">
				<h3>Contact Us via email to get a complete material</h3>
				<p>Send your request to <a href="mailto:sictrepository@futminna.edu.ng@">sictrepository@futminna.edu.ng</a> only.</p>

			</div>
			<!-- /FORM -->


			<!-- INFO -->
			<div class="col-md-4">

				<h4 class="font300">Postal Contact Details</h4>

				<p>
					<span class="block"><strong><i class="fa fa-map-marker"></i> Address:</strong> Federal University of Technology Minna, Bida Road, PMB 60, Nigeria</span>
					<span class="block"><strong><i class="fa fa-phone"></i> Phone:</strong> <a href="tel:08162456454">0816-245-6454</a></span>
					<span class="block"><strong><i class="fa fa-envelope"></i> Email:</strong> <a href="mailto:sictrepository@futminna.edu.ng@">sictrepository@futminna.edu.ng</a></span>
				</p>

				<div class="divider half-margins"><!-- divider --></div>

				<h4 class="font300">Working Hours</h4>
				<p>
					<span class="block"><strong>Monday - Friday:</strong> 8am to 4pm</span>
					<span class="block"><strong>Saturday:</strong> 10am to 2pm</span>
					<span class="block"><strong>Sunday:</strong> Closed</span>
				</p>

			</div>
			<!-- /INFO -->

		</div>

	</div>
</section>
<!-- /CONTENT -->
@stop