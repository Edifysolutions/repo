@extends('layout.master')
@section('content')
	@include('partials/pgTop')
	@include('admin/partials/topNav')
	<div class="col-md-12 col-sm-12">
		<div class="col-md-3 col-sm-12">@include('admin/partials/sideNav')</div>
		<div class="col-md-9 col-sm-12">
			<h3>Hey {{ucwords(Auth::user()->fullname)}}, Welcome to SICT repository dashbaord.</h3>
			<p>Perform all admin operations using the navigation on the left.</p>
			<a href="{{URL::route('getLogout')}}" title="Logout">Logout</a>
		</div>
	</div>
	@include('partials/pgBottom')
@stop