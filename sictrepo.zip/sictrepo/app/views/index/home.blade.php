@extends('layout.master')
@section('content')

	@include('partials/slider')
	<!-- WELCOME -->
			<section>
				<div class="container">
				
					<div class="row">
						<div class="col-md-12">
							<h2>
								WELCOME TO <b><i class="fa fa-score-board"></i> SCHOOL OF INFORMATION AND COMMUNICATION TECHNOLOGY (SICT) REPOSITORY, FUT MINNA.</b>
							</h2>
							<p class="lead">An online resource centre where you find all of SICT's student's project work (Only Undergraduate and Masters).<br>
							 With up to date projects from all the departments in the faculty.<br>
							 NOTE: Only the project abstract, student name, surpervisor and number of project pages are available.<br>

 							Complete project work can be made available on request, just visit our <a href="{{URL::route('getContact')}}">project request page</a> and lay your request.</p>
						
							<div class="margin-top20"><!-- buttons -->
								<a href="{{URL::route('getSearchBlank')}}" class="btn btn-success">GO TO PROJECT SEARCH <i class="fa fa-arrow-right"></i></a>
							</div><!-- /buttons -->
						</div>
				
					</div>

				</div>
			</section>
			<!-- /WELCOME -->

@stop
