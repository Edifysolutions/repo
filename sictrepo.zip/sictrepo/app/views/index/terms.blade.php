@extends('layout.master')
@section('content')

<!-- SECTION -->
			<section>
				<div class="container">
					
					<div class="row">
						<div class="col-md-12 col-sm-12">
							<h3><strong>Conditions</strong> and <strong>Terms</strong> </h3>
							<ul class="list-icon spaced check-circle">
								<li>All Projects are for <b>SALE.</b></li>
								<li>All Projects posted here are purely Ready-made Projects. With documentation.</li>
								<li>All Projects are <b>Genuine</b> and <b>Fully 100%</b> tested projects.</li>
								<li>You are advised to choose the right project get approval from supervisor buying.</li>
								<li>Students are also advised to view the abstracts clearly (posted in our website) before going to buy the project.</li>
								<li>Any statistical data, inputs, outputs, tables and diagrams presented in those projects are already done by various students.</li>
								<li>Complete Project Data and Full Project Documentation Reports will be provided by us along with the project.</li>
								<li>For MBA Project, Documentation contains everything.</li>
								<li>After full payment only the project will be sent to you within 2 working days.</li>
								<li>You can request to view project before buying.</li>
								<li><b>Technical projects</b> screen shots can be provided.</li>
								<li>If you need synopsis in some specific format other than what is listed on our website it will cost you extra.</li>
							</ul>

						</div>
						
					</div>

				</div>
			</section>
			<!-- /SECTION -->

@stop