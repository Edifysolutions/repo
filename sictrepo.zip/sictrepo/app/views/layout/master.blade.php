<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html lang="en"> <!--<![endif]-->
<head>
	<title>{{(empty($title)) ? '' : $title.' | ' }}SICT Repository Project Dev</title>
	<meta name="keywords" content="HTML5,CSS3,Template" />
	<meta name="description" content="" />
	<meta name="Author" content="Describe Group Ltd" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

	<!-- mobile settings -->
	<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />

	<!-- Favicon -->
	<!-- <link rel="shortcut icon" href="{{ asset('assets/images/demo/favicon.ico') }}" /> -->

	<!-- WEB FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800&amp;subset=latin,latin-ext,cyrillic,cyrillic-ext" rel="stylesheet" type="text/css" />

	<!-- CORE CSS -->
	<link href="{{ asset('assets/plugins/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/css/font-awesome.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/css/sky-forms.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/css/line-icons.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/plugins/owl-carousel/owl.pack.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/plugins/magnific-popup/magnific-popup.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/css/flexslider.css') }}" rel="stylesheet" type="text/css" />
	@yield('page_css')

	<!-- REVOLUTION SLIDER -->
	<link href="{{ asset('assets/css/revolution-slider.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/css/layerslider.css') }}" rel="stylesheet" type="text/css" />

	<!-- THEME CSS -->
	<link href="{{ asset('assets/css/essentials.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/css/layout.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/css/header-4.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/css/footer-default.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ asset('assets/css/color_scheme/red.css') }}" rel="stylesheet" type="text/css" id="color_scheme" />

	<!-- Morenizr -->
	<script type="text/javascript" src="{{ asset('assets/plugins/modernizr.min.js') }}"></script>

	<!--[if lte IE 8]>
		<script src="{{ asset('assets/plugins/respond.js') }}"></script>
	<![endif]-->
</head>
	
	<!-- 
		Background Image - add to body: 
			data-background="{{ asset('assets/images/boxed_background/1.jpg') }}"

		Examples: 
			<body class="smoothscroll grey boxed pattern3">
			<body class="smoothscroll boxed" data-background="{{ asset('assets/images/boxed_background/1.jpg') }}">
	-->
	<body class="smoothscroll grey boxed pattern11" id="content">

		<div id="wrapper">
		<?php $departments = Department::whereVisible(1)->get(); ?>
		@include('partials/header')

		@include('partials/n')

		@yield('content')

		@include('partials/footer')

		<a href="#" id="toTop"></a>

		</div><!-- /#wrapper -->

		<!-- JAVASCRIPT FILES -->
		<script type="text/javascript" src="{{ asset('assets/plugins/jquery-2.1.4.min.js') }}"></script>
		<script type="text/javascript" src="{{ asset('assets/plugins/jquery.isotope.js') }}"></script>
		<script type="text/javascript" src="{{ asset('assets/plugins/masonry.js') }}"></script>

		<script type="text/javascript" src="{{ asset('assets/plugins/bootstrap/js/bootstrap.min.js') }}"></script>
		<script type="text/javascript" src="{{ asset('assets/plugins/magnific-popup/jquery.magnific-popup.min.js') }}"></script>
		<script type="text/javascript" src="{{ asset('assets/plugins/owl-carousel/owl.carousel.min.js') }}"></script>
		<script type="text/javascript" src="{{ asset('assets/plugins/knob/js/jquery.knob.js') }}"></script>
		<script type="text/javascript" src="{{ asset('assets/plugins/flexslider/jquery.flexslider-min.js') }}"></script>

		<!-- REVOLUTION SLIDER -->
		<script type="text/javascript" src="{{ asset('assets/plugins/revolution-slider/js/jquery.themepunch.tools.min.js') }}"></script>
		<script type="text/javascript" src="{{ asset('assets/plugins/revolution-slider/js/jquery.themepunch.revolution.min.js') }}"></script>
		<script type="text/javascript" src="{{ asset('assets/js/revolution_slider.js') }}"></script>
		
		<script type="text/javascript" src="{{ asset('assets/js/scripts.js') }}"></script>
	</body>
</html>