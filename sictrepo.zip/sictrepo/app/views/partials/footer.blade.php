<!--FOOTER -->
<footer id="footer">
	
	<div class="copyright">
		<div class="container text-center fsize12">
			A PRODUCT OF <a href="http://www.futminna.edu.ng/" target="_blank" title="FEDERAL UNIVERSITY OF TECHNOLOGY, MINNA" class="copyright">FUT MINNA</a> &bull; All Right Reserved &copy; SICT REPOSITORY. &nbsp; 
			<!-- <a href="{{URL::route('getTerms')}}" class="fsize11">Terms of Service</a> -->
		</div>
	</div>
</footer>
<!-- /FOOTER -->