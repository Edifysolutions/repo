<div id="header"> 
	<!-- Top Bar -->
	<header id="topBar">
		<div class="container">

			<div class="pull-left fsize13 hide_mobile">

				<div class="block text-right"><!-- social -->
					<a href="#" class="social fa fa-facebook"></a>
					<a href="#" class="social fa fa-twitter"></a>
					<a href="#" class="social fa fa-google-plus"></a>
					<!-- <a href="#" class="social fa fa-linkedin"></a>
					<a href="#" class="social fa fa-pinterest"></a> -->
				</div><!-- /social -->

			</div>

			<div id="barMain">
				<nav class="nav-second">
					<ul class="nav nav-pills nav-second">
						<!-- <li><a href="{{URL::route('getAbout')}}"><i class="fa fa-angle-right"></i> About</a></li> -->
						@unless(Auth::check())
						<li><a href="{{URL::route('getLogin')}}"><i class="fa fa-angle-right"></i> Staff Login</a></li>
						@endunless
					</ul>
				</nav>
			</div>

		</div><!-- /.container -->
	</header>
	<!-- /Top Bar -->

	<!-- Top Nav -->
	<header id="topNav">
		<div class="container">

			<!-- Logo -->
			<!-- <a class="logo" href="{{URL::route('home')}}"> -->
				<!-- <img src="{{ asset('assets/images/logo.png') }}" height="50" alt="" /> -->
				<h2>SICT REPOSITORY FEDERAL UNIVERSITY OF TECHNOLOGY MINNA</h2>
			<!-- </a> -->

			<!-- Mobile Menu Button -->
			<button class="btn btn-mobile" data-toggle="collapse" data-target=".nav-main-collapse">
				<i class="fa fa-bars"></i>
			</button>

			<!-- Search -->
			<form class="search" method="get" action="{{URL::route('getSearch')}}">
				<input type="hidden" name="department" value="0">
				<input type="text" class="form-control" name="topic" value="" placeholder="Search">
				<button class="fa fa-search"></button>
			</form>
			<!-- /Search -->

			<!-- Top Nav -->
			<div class="navbar-collapse nav-main-collapse collapse">
				<nav class="nav-main">
					<ul id="topMain" class="nav nav-pills nav-main">
						<li class="mega-menu">
							<a href="{{URL::route('home')}}">
								HOME <span>welcome</span>
							</a>
						</li>
						<li class="dropdown">
							<a class="dropdown-toggle" href="#">DEPARTMENTS <span>select</span></a>
							<ul class="dropdown-menu">
								@foreach($departments as $department)
								<li><a href="{{URL::route('getProjectsForDept', $department->slug)}}"><i class="fa fa-arrow-right"></i> {{ $department->name }}</a></li>
								@endforeach
							</ul>
						</li>
						<li class="mega-menu">
							<a href="{{URL::route('getContact')}}">
								CONTACT <span>contact us</span>
							</a>
						</li>
						@if(Auth::check())
						<li class="mega-menu">
							<a href="{{URL::route('getDashboard')}}">
								DASHBOARD <span>dashboard</span>
							</a>
						</li>
						@endif
					</ul>

				</nav>
			</div>
			<!-- /Top Nav -->

		</div><!-- /.container -->
	</header>
	<!-- /Top Nav -->

</div>