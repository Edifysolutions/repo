@if (Session::has('m'))
<div class="alert alert-{{ Session::get('m_type', 'danger') }} alert-dismissable">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
  <strong><i class="fa fa-bell"></i> &nbsp;</strong> {{ Session::get('m') }}
</div>
@endif

