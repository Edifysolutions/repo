<!-- REVOLUTION SLIDER -->
<div class="slider fullwidthbanner-container roundedcorners">
	<div class="fullwidthbanner">
		<ul class="hide">

			<!-- SLIDE  -->
			<li data-transition="fade" data-slotamount="7" data-masterspeed="300" data-saveperformance="off" >

				<img src="{{ asset('assets/images/1x1.png') }}" data-lazyload="{{ asset('assets/images/demo/slide3.jpg') }}" alt="" data-bgfit="cover" data-bgposition="center top" data-bgrepeat="no-repeat" />

				<div class="tp-caption mediumlarge_light_white lfb tp-resizeme" 
					data-x="left" data-hoffset="70"
					data-y="133" 
					data-speed="1000" 
					data-start="1400" 
					data-easing="easeOutExpo" 
					data-splitin="none" 
					data-splitout="none" 
					data-elementdelay="0.1" 
					data-endelementdelay="0.1" 
					data-endspeed="300">+ Any time Any where
				</div>

				<div class="tp-caption mediumlarge_light_white lft tp-resizeme" 
					data-x="left" data-hoffset="70"
					data-y="85" 
					data-speed="1000" 
					data-start="1200" 
					data-easing="easeOutExpo" 
					data-splitin="none" 
					data-splitout="none" 
					data-elementdelay="0.1" 
					data-endelementdelay="0.1" 
					data-endspeed="300">+ Easy Project Search
				</div>

				<div class="tp-caption block_black sfl tp-resizeme" 
					data-x="70" 
					data-y="216" 
					data-speed="750" 
					data-start="1900" 
					data-easing="easeOutExpo" 
					data-splitin="none" 
					data-splitout="none" 
					data-elementdelay="0.1" 
					data-endelementdelay="0.1" 
					data-endspeed="300">Undergraduate Projects Repository
				</div>

				<div class="tp-caption block_black sfr tp-resizeme" 
					data-x="70" 
					data-y="260" 
					data-speed="750" 
					data-start="2200" 
					data-easing="easeOutExpo" 
					data-splitin="none" 
					data-splitout="none" 
					data-elementdelay="0.1" 
					data-endelementdelay="0.1" 
					data-endspeed="300">SICT, FUT Minna
				</div>

			</li>

			<!-- SLIDE  -->
			<li data-transition="fade" data-slotamount="7" data-masterspeed="300" data-link="http://www.describe.com.ng/" data-target="_blank" data-saveperformance="off" >

				<img src="{{ asset('assets/images/1x1.png') }}" data-lazyload="{{ asset('assets/images/demo/slide2.jpg') }}" alt="" data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat" />

				<div class="tp-caption block_black sfl tp-resizeme" 
					data-x="70" 
					data-y="172" 
					data-speed="750" 
					data-start="1000" 
					data-easing="easeOutExpo" 
					data-splitin="none" 
					data-splitout="none" 
					data-elementdelay="0.1" 
					data-endelementdelay="0.1" 
					data-endspeed="300">Read Project Abstract
				</div>

				<div class="tp-caption block_black sfl tp-resizeme" 
					data-x="70" 
					data-y="216" 
					data-speed="750" 
					data-start="1400" 
					data-easing="easeOutExpo" 
					data-splitin="none" 
					data-splitout="none" 
					data-elementdelay="0.1" 
					data-endelementdelay="0.1" 
					data-endspeed="300">Get Project Details
				</div>

				<div class="tp-caption block_black sfr tp-resizeme" 
					data-x="70" 
					data-y="260" 
					data-speed="750" 
					data-start="1800" 
					data-easing="easeOutExpo" 
					data-splitin="none" 
					data-splitout="none" 
					data-elementdelay="0.1" 
					data-endelementdelay="0.1" 
					data-endspeed="300">Request for Complete Project Work
				</div>

			</li>

			<!-- SLIDE  -->
			<li data-transition="fade" data-slotamount="14"  data-masterspeed="300" data-delay="10000">

				<!-- COVER IMAGE -->
				<img src="{{ asset('assets/images/1x1.png') }}" data-lazyload="{{ asset('assets/images/demo/slide1.jpg') }}" alt="" data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat" />

				<div class="tp-caption medium_text lfl stl"
					data-x="60"
					data-y="200"
					data-speed="300"
					data-start="500"
					data-easing="easeOutExpo">
				</div>

				<div class="tp-caption large_bold_white sft stb"
					data-x="60"
					data-y="223"
					data-speed="300"
					data-start="1000"
					data-easing="easeOutExpo">
				</div>

				<div class="tp-caption small_light_white sft stb"
					data-x="76"
					data-y="286"
					data-speed="500"
					data-start="2000"
					data-easing="easeOutExpo">
				</div>

				<div class="tp-caption sft medium_light_white" 
					data-x="600" 
					data-y="60" 
					data-speed="600" 
					data-start="1500" 
					data-easing="easeOutExpo"><!-- <img src="{{ asset('assets/images/demo/desktop_slider.png') }}" alt="" /> FUT logo here-->
				</div>

			</li>

		</ul>
		<div class="tp-bannertimer"></div>
	</div>
</div>
<!-- /REVOLUTION SLIDER -->