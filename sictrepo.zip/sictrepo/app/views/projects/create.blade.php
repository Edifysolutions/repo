@extends('layout.master')
@section('content')

	@include('partials/pgTop')
	@include('admin/partials/topNav')
	<div class="col-md-12 col-sm-12">
		<div class="col-md-3 col-sm-12">@include('admin/partials/sideNav')</div>
		<div class="col-md-9 col-sm-12">
			<form action="{{ URL::route('project.store') }}" method="post" class="sky-form boxed">
				<input type="hidden" name="_token" value="{{ csrf_token() }}">
				<header>Create Project Form</header>

				<fieldset>
					<div class="row">
						<section class="col col-md-6">
							<label class="label">Department</label>
							<label class="input">
								<select name="department" class="form-control">
			             			@foreach($departments as $department)
			             				<option value="{{ $department->id }}">{{ $department->name }}</option>
			             			@endforeach
			             		</select>
							</label>
						</section>
						<section class="col col-md-6">
							<label class="label">Year of Submission:</label>
							<label class="input">
								<!-- <i class="icon-append fa fa-phone"></i> -->
								<input name="year_of_submission" type="text" value="{{ Input::old('year_of_submission') }}" required>
								<b class="tooltip tooltip-bottom-right">e.g 2015</b>
								@if($errors->has('year_of_submission'))
              					<div class="alert alert-danger">{{ $errors->first('year_of_submission') }}</div>
              					@endif
							</label>
						</section>
					</div>

					<div class="row">
						<section class="col col-md-6">
							<label class="label">Student Name:</label>
							<label class="input">
								<!-- <i class="icon-append fa fa-envelope"></i> -->
								<input name="student_name" required type="text" value="{{ Input::old('student_name') }}">
								<b class="tooltip tooltip-bottom-right">Enter the name of the student e.g Nengolong Samuel</b>
								@if($errors->has('student_name'))
				              	<div class="alert alert-danger">{{ $errors->first('student_name') }}</div>
				              	@endif
							</label>
						</section>
						<section class="col col-md-6">
							<label class="label">Surpervisor Name:</label>
							<label class="input">
								<!-- <i class="icon-append fa fa-phone"></i> -->
								<input name="surpervisor_name" type="text" value="{{ Input::old('surpervisor_name') }}" required>
								<b class="tooltip tooltip-bottom-right">Project Surpervisor e.g Dr J.K. Alhassan</b>
								@if($errors->has('surpervisor_name'))
              					<div class="alert alert-danger">{{ $errors->first('surpervisor_name') }}</div>
              					@endif
							</label>
						</section>
					</div>

					<div class="row">
						<section class="col col-md-12">
							<label class="label">Project Topic:</label>
							<label class="input">
								<input type="text" name="topic" value="{{ Input::old('topic') }}" required>
								<b class="tooltip tooltip-bottom-right">e.g DESIGN AND IMPLEMENTATION OF CLASS BASED...</b>
								@if($errors->has('topic'))
              					<div class="alert alert-danger">{{ $errors->first('topic') }}</div>
              					@endif
							</label>
						</section>
					</div>

					<label class="label">Project Body:</label>
					<label class="textarea">
						<!-- <i class="icon-append fa fa-pencil-square-o"></i> -->
						<textarea rows="15" name="body" id="txtarea">{{Input::old('body')}}</textarea>
						<!-- <b class="tooltip tooltip-bottom-right">Only latin characters and numbers</b> -->
						@if($errors->has('body'))
              			<div class="alert alert-danger">{{ $errors->first('body') }}</div>
              			@endif
					</label>
					<br>

					<section class="col col-md-6">
						<label class="label">Methodology <span class="text-muted">(optional)</span>:</label>
						<label class="input">
							<!-- <i class="icon-append fa fa-user"></i> -->
							<input name="methodology" type="text" value="{{ Input::old('methodology') }}">
							<b class="tooltip tooltip-bottom-right">e.g Top-down design, bottom-up design</b>
							@if($errors->has('methodology'))
              				<div class="alert alert-danger">{{ $errors->first('methodology') }}</div>
              				@endif
						</label>
					</section>
					<section class="col col-md-6">
						<label class="label">References <span class="text-muted">(optional)</span>:</label>
						<label class="input">
							<!-- <i class="icon-append fa fa-user"></i> -->
							<input name="references" type="text" value="{{ Input::old('references') }}">
							<b class="tooltip tooltip-bottom-right">e.g http://wikipedia.com/Topic</b>
							@if($errors->has('references'))
              				<div class="alert alert-danger">{{ $errors->first('references') }}</div>
              				@endif
						</label>
					</section>

					<div class="form-group">
						<div class="col-md-4 col-sm-12 col-xs-12 nopadding">
							<label for="visible">Make Project Visible Online? </label>
						</div>
						<div class="col-md-8 nopadding">
							<div class="row">
								<div class="col-md-2 col-sm-2 col-xs-4"><!-- selected="selected" radio below uses checked -->
									<label class="radio"><input type="radio" name="visible" value="1" checked="checked"><i></i>Yes</label>
								</div>
								<div class="col-md-10 col-sm-2 col-xs-8">
									<label class="radio"><input type="radio" name="visible" value="0"><i></i>No</label>
								</div>
							</div>
						</div>
					</div>


				</fieldset>

				<footer>
					<button type="submit" class="button"><i class="fa fa-check"></i> Create Project</button>
				</footer>

			</form>
			
		</div>
	</div>
	@include('partials/pgBottom')

{{ HTML::script('assets/tinymce/js/tinymce/tinymce.min.js') }}
<script>
	tinymce.init({
		selector: '#txtarea',
		skin: 'pepper-grinder',
		plugins: 
			'wordcount, insertdatetime,'
		});
</script>
<!--end tinymce -->
@stop