@extends('layout.master')
@section('content')

@include('partials/pgTop')
	<div class="col-md-12 col-sm-12 col-xs-12">
	| <a href="javascript:history.go(-1)">Back</a> | <br> 

	@if($projects->count())
	<table class="table table-bordered table-hover">
	<thead>
		<th class="text-center"><i class="fa fa-certificate"></i> AVAILABLE PROJECT TOPICS</th>
	</thead>
	<tbody>
	<?php $sn=1; ?>
	@foreach($projects as $project)
		 <tr>
			<td class="text-center overflow-hidden">
				<a href="{{URL::route('getProjectItem', [$project->department->slug, $project->project_number])}}" title="{{ $project->title }}"><i class="fa fa-sign-out"></i>
				@if(strlen($project->title) > 100)  {{ substr($project->title, 0, 100).'...' }} @else {{ $project->title }} @endif 
				</a>
			</td>
		</tr>
	@endforeach
	</tbody>
	</table>
	<div align="center"> 
		{{ $projects->links() }}
	</div>
	@else

	<h3 class="text-info"> {{ 'There are no available projects at the moment' }} </h3>

	@endif
	</div>

@include('partials/pgBottom')

@stop