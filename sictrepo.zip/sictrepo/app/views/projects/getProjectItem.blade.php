@extends('layout.master')
@section('page_css')
<link href="{{ asset('assets/css/layout-blog.css') }}" rel="stylesheet" type="text/css" />
@stop
@section('content')

@include('partials/pgTop')
<div class="col-md-12 col-sm-12 col-xs-12">
	| <a href="javascript:history.go(-1)"><i class="fa fa-arrow-left"></i> Back</a> | <a href="#"><i class="fa fa-print"></i> Print Page</a><br> 
		<!-- PAGE TOP -->
		<section class="page-title">
			<div class="container">

				<header>

					<ul class="breadcrumb"><!-- breadcrumb -->
						<li><a href="{{URL::route('getProjectsForDept', $project->department->slug)}}">{{ $project->department->name }}</a></li>
						<li class="active">{{ $project->topic }}</li>
					</ul><!-- /breadcrumb -->

					<h2 class="hidden-xs"><!-- Page Title -->
						{{ $project->topic }}
					</h2><!-- /Page Title -->

				</header>

			</div>			
		</section>
		<!-- /PAGE TOP -->

		<!-- CONTENT -->
		<section>
			<div class="container">

				<div id="blog" class="row">

					<!-- BLOG ARTICLE LIST -->
					<div class="col-md-9 col-sm-9">
					
						<!-- article -->
						<div class="prev-article row">
							
								<span class="info col-xs-12 col-sm-12">
									<span class="block hidden-md hidden-lg"><i class="fa fa-calendar"></i> YEAR OF SUBMISSION: {{ $project->year_of_submission }}</span>
									<span class="block"><i class="fa fa-user"></i> STUDENT NAME: {{ $project->student_name }}</span>
									<span class="block"><i class="fa fa-user"></i> SURPERVISOR NAME: {{ $project->surpervisor_name }}</span>
									@unless(empty($project->methodology))
									<span class="block"><i class="fa fa-file-o"></i> METHODOLOGY: {{ $project->methodology }}</span>
									@endunless
									@unless(empty($project->references))
									<span class="block"><i class="fa fa-link"></i> REFERENCES: {{ $project->references }}</span>
									@endunless
								</span>
								<span><h4><a href="{{URL::route('getContact')}}" class="btn btn-primary">Request for Complete Material <i class="fa fa-arrow-right"></i></a></h4></span>
							

							
								{{ strip_tags($project->body, "<b><p><br><i><u><a><h1><h2><h3><h4<h5><h6><strong><embed><object><param><small><span><em><img>") }}
								<br>
								<a href="{{URL::route('getContact')}}" class="btn btn-success">Request for Complete Project (Material) <i class="fa fa-arrow-right"></i></a>
							</div>
						
					</div>
					<!-- /BLOG ARTICLE LIST -->

					<!-- BLOG SIDEBAR -->
					<div class="col-md-3 col-sm-3">
					
						<!-- RECENT,POPULAR -->
						<div class="widget">

							<!-- TABS -->
							<div class="tabs nomargin-top">

								<!-- tabs -->
								<ul class="nav nav-tabs nav-justified">
									<li class="active">
										<a href="#tab1" data-toggle="tab">
											Related Projects
										</a>
									</li>
								</ul>

								<!-- tabs content -->
								<div class="tab-content">
									<div id="tab1" class="tab-pane active">
										<ul>
											@if($rProjects->count())
					                        @foreach($rProjects as $rProject)
					                        @if($project->id !== $rProject->id)
				                                <li>
				                                    <a href="{{URL::route('project.show', $rProject->id)}}"><i class="fa fa-sign-out"></i> {{substr($rProject->topic, 0, 55).'...'}} </a> 
				                                    <small>By {{ $project->student_name }} submitted in {{ $project->year_of_submission }}</small>
				                                </li>
					                        @endif
					                        @endforeach
					                        @else
					                            <li><h5 class="text-info">No related Projects available</h5></li>
					                        @endif
										</ul>
									</div>
								</div>

							</div>
							<!-- /TABS -->

						</div>
						<!-- /RECENT,POPULAR -->

					</div>
					<!-- /BLOG SIDEBAR -->

				</div>


			</div>
		</section>
		<!-- /CONTENT -->

</div>
@include('partials/pgBottom')

@stop