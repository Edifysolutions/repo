@extends('layout.master')
@section('content')

@include('partials/pgTop')
	<div class="col-md-12 col-sm-12 col-xs-12">
	| <a href="javascript:history.go(-1)"><i class="fa fa-arrow-left"></i> Back</a> | 

	@if($projects->count())
	<a href="#"><i class="fa fa-print"></i> Print Page</a>
	<table class="table table-bordered table-hover">
	<thead>
		<!-- <th class="text-center"><i class="fa fa-certificate"></i> AVAILABLE PROJECT TOPICS</th> -->
		<th class="text-center">
			<form method="get" action="{{URL::route('getSearch')}}" class="sky-form boxed text-center">
			<header class="text-center">Search available projects in {{ $department->name }} department</header>

				<fieldset>
					<div class="row text-center">
						<input type="hidden" name="department" value="{{$department->id}}">
						&nbsp;
						<label for="year">Project Topic:</label>
						<input type="text" name="topic" value="{{Input::old('topic')}}" placeholder="e.g SICT Repository">
						&nbsp;
						<label for="year">Year:</label>
						<input type="text" name="year_of_submission" value="{{Input::old('year_of_submission')}}" placeholder="e.g 2015">
						&nbsp;
						<label for="year">Student Name:</label>
						<input type="text" name="student_name" value="{{Input::old('student_name')}}" placeholder="e.g Nengolong Samuel">
						&nbsp;
						<label for="year">Surpervisor Name:</label>
						<input type="text" name="surpervisor_name" value="{{Input::old('surpervisor_name')}}" placeholder="e.g Dr J.K. Alhassan">
						&nbsp;
						<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i>Search</button>
					</div>
				</fieldset>
			</form>
			<i class="fa fa-certificate"></i> {{ ($projects->count()) ? count($projects).' project(s) found' : '0 results were found' }}
		</th>
	</thead>
	<tbody>
	<?php $sn=1; ?>
	@foreach($projects as $project)
		 <tr>
			<td class="text-center overflow-hidden">
				<a href="{{URL::route('project.show', $project->id)}}" title="{{ $project->topic }}"><i class="fa fa-sign-out"></i>
				@if(strlen($project->topic) > 90)  {{ substr($project->topic, 0, 90).'...' }} @else {{ $project->topic }} @endif 
				</a> - <small title="{{ str_replace('<br>', ' | ', $project->student_name) }}">By {{ (strlen($project->student_name) > 42) ? substr($project->student_name, 0, 42).'...' : $project->student_name }}</small>
			</td>
		</tr>		
	@endforeach
	</tbody>
	</table>
	<div align="center"> 
		{{ $projects->links() }}
	</div>

	@else

	<h3 class="text-info"> {{ 'There are no available projects at the moment' }} </h3>

	@endif
	</div>

@include('partials/pgBottom')

@stop