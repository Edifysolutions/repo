@extends('layout.master')
@section('content')

@include('partials/pgTop')
	<div class="col-md-12 col-sm-12 col-xs-12">
	| <a href="javascript:history.go(-1)">Back</a> | 
	@if( $errors->count() )
	  <div class="alert alert-danger alert-dismissable">
	  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	  <strong>We encountered the following errors:</strong>
	  <ul>
	    @foreach($errors->all() as $message)
	    <li>{{ $message }}</li>
	    @endforeach
	  </ul>
	  </div>
	@endif
	<table class="table table-bordered table-hover">
	<thead>
		<!-- <th class="text-center"><i class="fa fa-certificate"></i> AVAILABLE PROJECT TOPICS</th> -->
		<th class="text-center">
			<form method="get" action="{{URL::route('getSearch')}}" class="sky-form boxed text-center">
			<header class="text-center">Search available projects</header>

				<fieldset>
					<div class="row text-center">
						<select name="department"><?php $departments = Department::whereVisible(1)->get();
							$getDept = Request::get('department'); ?>
							<option value="0">All</option>
							@foreach($departments as $department)
							<option value="{{$department->id}}" {{ ($department->id == $getDept) ? 'selected="selected"' : '' }}>{{ $department->name }}</option>
							@endforeach
						</select>
						<br>
						<label for="year">Project Topic:</label>
						<input type="text" name="topic" value="{{Input::old('topic')}}" placeholder="e.g SICT Repository">
						&nbsp;
						<label for="year">Year:</label>
						<input type="text" name="year_of_submission" value="{{Input::old('year_of_submission')}}" placeholder="e.g 2015">
						&nbsp;
						<label for="year">Student Name:</label>
						<input type="text" name="student_name" value="{{Input::old('student_name')}}" placeholder="e.g Nengolong Samuel">
						&nbsp;
						<label for="year">Surpervisor Name:</label>
						<input type="text" name="surpervisor_name" value="{{Input::old('surpervisor_name')}}" placeholder="e.g Dr J.K. Alhassan">
						&nbsp;
						<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i>Search</button>
					</div>
				</fieldset>
			</form>
			
		</th>
	</thead>
	<tbody>
		<tr>
			<td class="text-center overflow-hidden">
				<h4 class="text-muted"> {{ 'Search results will appear here' }} </h4>
			</td>
		</tr>		
	</tbody>
	</table>
	


@include('partials/pgBottom')

@stop