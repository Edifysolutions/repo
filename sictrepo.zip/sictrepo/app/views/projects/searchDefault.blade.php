@extends('layout.master')
@section('content')

@include('partials/pgTop')
	<div class="col-md-12 col-sm-12 col-xs-12">
	| <a href="javascript:history.go(-1)"><i class="fa fa-arrow-left"></i> Back</a> | <a href="#" onclick="Clickheretoprint()"><i class="fa fa-print"></i> Print Page</a>

	<table class="table table-bordered table-hover">
	<thead>
		<th class="text-center">
			<form method="get" action="{{URL::route('getSearch')}}" class="sky-form boxed text-center">
			<header class="text-center">Search available projects</header>

				<fieldset>
					<div class="row text-center">
						<select name="department"><?php $departments = Department::whereVisible(1)->get();
						$getDept = Request::get('department'); ?>
							<option value="0">All</option>
							@foreach($departments as $department)
							<option value="{{$department->id}}" {{ ($department->id == $getDept) ? 'selected="selected"' : '' }}>{{ $department->name }}</option>
							@endforeach
						</select>
						<br>
						<label for="year">Project Topic:</label>
						<input type="text" name="topic" value="{{$topic}}" placeholder="e.g SICT Repository">
						&nbsp;
						<label for="year">Year:</label>
						<input type="text" name="year_of_submission" value="{{$year_of_submission}}" placeholder="e.g 2015">
						&nbsp;
						<label for="year">Student Name:</label>
						<input type="text" name="student_name" value="{{$student_name}}" placeholder="e.g Nengolong Samuel">
						&nbsp;
						<label for="year">Surpervisor Name:</label>
						<input type="text" name="surpervisor_name" value="{{$surpervisor_name}}" placeholder="e.g Dr J.K. Alhassan">
						&nbsp;
						<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i>Search</button>
					</div>
				</fieldset>
			</form>
		<i class="fa fa-certificate"></i> {{ ($searchResults->count()) ? count($searchResults).' project(s) found' : '0 results were found' }}
		</th>
	</thead>
	<tbody>
	@if($searchResults->count())
	@foreach($searchResults as $project)
		 <tr>
			<td class="text-center overflow-hidden">
				<a href="{{URL::route('project.show', $project->id)}}" title="{{ $project->topic }}"><i class="fa fa-sign-out"></i>
				@if(strlen($project->topic) > 90)  {{ substr($project->topic, 0, 90).'...' }} @else {{ $project->topic }} @endif 
				</a> - <small>{{ $project->department->name }} | {{$project->year_of_submission}}</small>
			</td>
		</tr>		
	@endforeach
	@else
	<tr><td class="text-center overflow-hidden"> {{ 'No result was found matching your query' }} </td></tr>
	@endif
	</tbody>
	</table>
	<div align="center"> 
		{{ $searchResults->links() }}
	</div>
	
	</div>

@include('partials/pgBottom')
<script type="text/javascript">
	
	function Clickheretoprint()
	{ 
	  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
	      disp_setting+="scrollbars=yes,width=900, height=400, left=100, top=25"; 
	  var content_vlue = document.getElementById("content").innerHTML; 
	  
	  var docprint=window.open("","",disp_setting); 
	   docprint.document.open(); 
	   docprint.document.write('<link href="assets/css/bootstrap.min.css" rel="stylesheet"></head><body onLoad="self.print()"><div class="container">');          
	   docprint.document.write(content_vlue); 
	   docprint.document.close(); 
	   docprint.focus(); 
	}
</script>
@stop
