@extends('layout.master')
@section('content')
@include('partials/pgTop')
	@include('admin/partials/topNav')
	<div class="col-md-12 col-sm-12">
		<div class="col-md-3 col-sm-12">@include('admin/partials/sideNav')</div>
		<div class="col-md-9 col-sm-12">
			<form action="{{route('addPost')}}" method="post" class="sky-form boxed">
				<input type="hidden" name="_token" value="{{ csrf_token() }}">
				<header>Create Project Form</header>

				<fieldset>
					<div class="row">
						<section class="col col-md-6">
							<label class="label">Department</label>
							<label class="input">
								<select name="department" class="form-control">
								@foreach($dept as $dpt)
			             				<option value="{{$dpt->name}}">{{$dpt->name}}</option>
			             		@endforeach
			             		</select>
							</label>
						</section>
						<section class="col col-md-6">
							<label class="label">User Level</label>
							<label class="input">
								<select name="user_level" class="form-control">
			             				<option value="1">Staff</option>

			             		</select>
							</label>
						</section>
					</div>

					<div class="row">
						<section class="col col-md-6">
							<label class="label">User Name:</label>
							<label class="input">
								<!-- <i class="icon-append fa fa-phone"></i> -->
								<input name="username" type="text" value="{{ Input::old('username') }}" required>
								<b class="tooltip tooltip-bottom-right">username e.g Alhassan</b>
								@if($errors->has('username'))
              					<div class="alert alert-danger">{{ $errors->first('username') }}</div>
              					@endif
							</label>
						</section>
						<section class="col col-md-6">
							<label class="label">Password:</label>
							<label class="input">
								<!-- <i class="icon-append fa fa-phone"></i> -->
								<input name="password" type="text" value="{{ Input::old('password') }}" required>
								<b class="tooltip tooltip-bottom-right">Password e.g Dr JKA1234</b>
								@if($errors->has('password'))
              					<div class="alert alert-danger">{{ $errors->first('password') }}</div>
              					@endif
							</label>
						</section>
					</div>

					<div class="row">
						<section class="col col-md-12">
							<label class="label">User Full Name:</label>
							<label class="input">
								<input type="text" name="fullname" value="{{ Input::old('fullname') }}" required>
								<b class="tooltip tooltip-bottom-right">e.g DESIGN AND IMPLEMENTATION OF CLASS BASED...</b>
								@if($errors->has('fullname'))
              					<div class="alert alert-danger">{{ $errors->first('fullname') }}</div>
              					@endif
							</label>
						</section>
					</div>

					
					<br>
				

					<div class="form-group">
						<div class="col-md-4 col-sm-12 col-xs-12 nopadding">
							<label for="visible">Make Staff Visible ? </label>
						</div>
						<div class="col-md-8 nopadding">
							<div class="row">
								<div class="col-md-2 col-sm-2 col-xs-4"><!-- selected="selected" radio below uses checked -->
									<label class="radio"><input type="radio" name="visible" value="1" checked="checked"><i></i>Yes</label>
								</div>
								<div class="col-md-10 col-sm-2 col-xs-8">
									<label class="radio"><input type="radio" name="visible" value="0"><i></i>No</label>
								</div>
							</div>
						</div>
					</div>


				</fieldset>

				<footer>
					<button type="submit" class="button"><i class="fa fa-check"></i> Create Project</button>
				</footer>

			</form>
		</div>
	</div>
	@include('partials/pgBottom')

@stop