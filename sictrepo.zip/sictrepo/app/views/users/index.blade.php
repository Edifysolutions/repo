@extends('layout.master')
@section('content')
@include('partials/pgTop')
	@include('admin/partials/topNav')

		<div class="col-md-12 col-sm-12">
    <div class="col-md-3 col-sm-12">@include('admin/partials/sideNav')</div>
    <div class="col-md-9 col-sm-12">

       <table class="table table-striped" style="width:inherit;overflow:break">
       	<thead>
       		<th width="100px">Staff Full Name</th>
       		<th class="text-center">DEPARTMENT</th>
       		<th class="text-center">Active</th>
          <th class="text-center">Action</th>
       	</thead>
       	<tbody>
       		@foreach($staffs as $staff)
       			<tr>
       				<td width="100px">
                <a href="" class="btn" title="Click to edit "> 
                  {{$staff->fullname}}
                </a>
              </td>
       				<td class="text-center"> {{ $staff->department }} </td>
       				<td class="text-center" >
       				@if($staff->visible == 1)
       				   <font color="green">  Active </font>
       				@else
       				    <font color="red">  Inactive </font>
       				@endif
       				</td>
              <td class="text-center"> <a href="{{URL('DeleteUser', $staff->id)}}">Delete</a> | <a href="#">View</a> </td>
       			</tr>
       		@endforeach
       	</tbody>
       </table>
       <br>

       </div><!-- end col-md-9 -->

     </div>


	@include('partials/pgBottom')

@stop