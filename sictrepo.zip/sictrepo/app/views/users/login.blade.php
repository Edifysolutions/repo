@extends('layout.master')
@section('content')

	@include('partials/pgTop')
		<div style="padding:0px 20px"> 
			@if( $errors->count() )
			  <div class="alert alert-danger alert-dismissable">
			  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			  <strong>We encountered the following errors:</strong>
			  <ul>
			    @foreach($errors->all() as $message)
			    <li>{{ $message }}</li>
			    @endforeach
			  </ul>
			  </div>
			@endif
			<!-- login FORM -->
			<form action="{{URL::route('postLogin')}}" method="post" class="sky-form col-md-8 col-sm-12 boxed" style="padding:10px;">
				<header>Staff Login Form</header>
				{{Form::token()}}
				<fieldset>					
					<div class="row">
						<section class="col col-md-6 form-group">
							<label class="label">Username</label>
							<label class="input">
								<i class="icon-append fa fa-user"></i>
								<input type="text" name="username" tabindex="1" value="{{Input::old('username')}}" required>
								<b class="tooltip tooltip-bottom-right">Needed to verify your account</b>
							</label>
						</section>
						<section class="col col-md-6 form-group">
							<label class="label">Password</label>
							<label class="input">
								<i class="icon-append fa fa-lock"></i>
								<input type="password" name="password" tabindex="2" required>
								<b class="tooltip tooltip-bottom-right">Only alphabets, punctuations and numbers</b>
							</label>
						</section>
						
					</div>
				
				</fieldset>
				
				<footer class="text-center">
					<button type="submit" class="button">Login <i class="fa fa-arrow-right"></i></button>
				</footer>
			</form>
			<!-- /login FORM -->
		</div>
	@include('partials/pgBottom')

@stop